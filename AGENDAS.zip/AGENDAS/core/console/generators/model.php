/**
 * Modelo <?= $class ?>
 * 
 * @category App
 * @package Models
 */
class <?= $class ?> extends ActiveRecord
{

}