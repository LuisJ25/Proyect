<?php

/**
 * Controller por defecto si no se usa el routes
 *
 */
class IndexController extends AppController
{

    public function index()
    {
        $this->title = "Inicio";
        $this->subtitle = "Bienvenido";

        /*- - - - - - - - - Ventas - - - - - - - - - - - - - - - -*/
        /*
        $this->ventas = (new Ventas())->find(19);
        $productos = (new Productos())->find(random_int(1,100));

        $cantidad = random_int(1,100);
        $this->ventas->add_item($productos, $cantidad);
        */

    }

}
