<?php

// app/controller/productos_controller.php
class AgendasController extends AppController{
    //- - - - - - - - - - - - - - INDEX  - - - - - - - - - - - - - //

    public function index(){
        // Verificar autenticación
        if (!Auth::is_valid()) {
            Flash::error("Debes iniciar sesión para acceder a esta sección");
            Redirect::to("login");
            return;
        }
        
        // Verificar permisos - solo Lolita25 puede acceder a Agendas
        if (Auth::get('username') !== 'Lolita' && Auth::get('username') !== 'Mane') {
            Redirect::to("index");
            return;
        }
        
        $this->title = "Agendas";
        $this->subtitle = "Lista de los solicitante";
        //Tablas de la base de datos
        $this->agendas = (new Agendas())->find();
    }
    
    //- - - - - - - - - - - - - - EXPORTAR MES  - - - - - - - - - - - - - //
    public function exportar_mes($year = null, $month = null){
        // Verificar autenticación
        if (!Auth::is_valid()) {
            Flash::error("Debes iniciar sesión para acceder a esta sección");
            Redirect::to("login");
            return;
        }
        
        // Verificar permisos - solo Lolita25 puede acceder a Agendas
        if (Auth::get('username') !== 'Lolita' && Auth::get('username') !== 'Mane') {
            Redirect::to("index");
            return;
        }
        
        // Obtener parámetros
        if (!$year) $year = Input::get('year');
        if (!$month) $month = Input::get('month');
        
        // Validar parámetros
        if (!$year || !$month) {
            Flash::error("Parámetros de fecha inválidos");
            Redirect::to("agendas/");
            return;
        }
        
        // Validar que sean números válidos
        if (!is_numeric($year) || !is_numeric($month) || $month < 1 || $month > 12) {
            Flash::error("Parámetros de fecha inválidos");
            Redirect::to("agendas/");
            return;
        }
        
        // Formatear el mes para que tenga 2 dígitos
        $monthFormatted = str_pad($month, 2, '0', STR_PAD_LEFT);
        
        // Crear el rango de fechas para el mes
        $startDate = "{$year}-{$monthFormatted}-01";
        $endDate = date('Y-m-t', strtotime($startDate)); // Último día del mes

        // Consultar agendas del mes específico
        $agendas = (new Agendas())->find("conditions: fecha BETWEEN '$startDate' AND '$endDate'");
        
        if (!$agendas || count($agendas) === 0) {
            Flash::error('No hay datos para el mes seleccionado');
            Redirect::to("agendas/");
            return;
        }

        // Desactivar la vista
        View::select(null, null);
        
        // SOLUCIÓN: Cambiar a CSV que es más simple y confiable
        header("Content-Type: text/csv; charset=utf-8");
        header("Content-Disposition: attachment; filename=agendas_mes_{$monthFormatted}_{$year}.csv");
        header("Pragma: no-cache");
        header("Expires: 0");
        
        // Crear output
        $output = fopen('php://output', 'w');
        
        // BOM para UTF-8 (para caracteres especiales)
        fwrite($output, "\xEF\xBB\xBF");
        
        // Encabezados
        fputcsv($output, [
            'Nombre', 'Edad', 'Discapacidad', 'CURP', 'Teléfono', 'Correo',
            'Escolaridad', 'Especialidad', 'Idioma adicional', 'Puesto 1 Solicitado', 
            'Puesto 2 Solicitado', 'Consejero', 'Estado', 'Municipio', 'Colonia',
            'Experiencia puesto 1', 'Experiencia puesto 2', 'Fecha'
        ]);
        
        // Datos
        foreach ($agendas as $agenda) {
            fputcsv($output, [
                $agenda->nombrec ?? '',
                $agenda->edad ?? '',
                $agenda->discapacidad ?? '',
                $agenda->curp ?? '',
                $agenda->telefono ?? '',
                $agenda->correo ?? '',
                $agenda->escolaridad ?? '',
                $agenda->especialidad ?? '',
                $agenda->idioma ?? '',
                $agenda->puesto1 ?? '',
                $agenda->puesto2 ?? '',
                $agenda->consejero ?? '',
                $agenda->estado ?? '',
                $agenda->municipio ?? '',
                $agenda->colonia ?? '',
                $agenda->experiencia1 ?? '',
                $agenda->experiencia2 ?? '',
                $agenda->fecha ?? ''
            ]);
        }
        
        fclose($output);
        exit;
    }

    //- - - - - - - - - - - - - - SHOW  - - - - - - - - - - - - - //
    public function show($id){
        // Verificar autenticación
        if (!Auth::is_valid()) {
            Flash::error("Debes iniciar sesión para acceder a esta sección");
            Redirect::to("login");
            return;
        }
        
        // Verificar permisos - solo Lolita25 puede acceder a Agendas
        if (Auth::get('username') !== 'Lolita' && Auth::get('username') !== 'Mane') {
            Redirect::to("index");
            return;
        }
        
        $this->title = "Informacion";
        $this->subtitle = "Informacion del solicitante";
        $this->agendas = (new Agendas())->find($id);
    }
    //- - - - - - - - - - - - - - REGISTRAR  - - - - - - - - - - - - - //
    public function registrar()
    {
        // Verificar autenticación
        if (!Auth::is_valid()) {
            Flash::error("Debes iniciar sesión para acceder a esta sección");
            Redirect::to("login");
            return;
        }
        
        // Verificar permisos - solo Lolita25 puede acceder a Agendas
        if (Auth::get('username') !== 'Lolita' && Auth::get('username') !== 'Mane') {
            Redirect::to("index");
            return;
        }
        
        $this->title = "Registrar";
        $this->subtitle = "Registrar nuevo solicitante";

        if (Input::hasPost('agendas')) {
            $datos = Input::post('agendas');

            // Llamar a la función de validación
            $validacion = $this->validar($datos);
            if ($validacion !== true) {
                Flash::error($validacion);
                return;
            }
            // Crear el objeto de cliente
            $agendas = new Agendas($datos);
            if ($agendas->create()) {
                Flash::valid("El solicitante se a registrado con éxito");
                Input::delete();
            } else {
                Flash::error("Error al registrar al solicitante");
            }
        }
    }
    // - - - - - - - - - - - - - - - - - -  -  (VALIDACIONES) - - - - - - - - - - - - - - - - - - - - - - //
            private function validar($datos)
        {
            // Validar que los campos obligatorios no estén vacíos
            $camposObligatorios = [
                'nombrec' => 'Nombre del cliente',
                'edad' => 'Edad',
                'curp' => 'CURP',
                'telefono' => 'Teléfono',
                'correo' => 'Email',
                'escolaridad' => 'Escolaridad',
                'consejero' => 'Consejero',
                'estado' => 'Estado',
                'municipio' => 'Municipio',
                'fecha' => 'Fecha'
            ];

            foreach ($camposObligatorios as $campo => $nombre) {
                if (empty(trim($datos[$campo] ?? ''))) {
                    return "El campo '$nombre' es obligatorio.";
                }
            }

            // Validar nombre del cliente (3-30 caracteres, solo letras y espacios)
            $nombre = trim($datos['nombrec']);
            if (strlen($nombre) < 3 || strlen($nombre) > 30) {
                return "El nombre debe tener entre 3 y 30 caracteres.";
            }
            if (!preg_match('/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/', $nombre)) {
                return "El nombre solo puede contener letras y espacios.";
            }

            // Validar edad (1-120 años)
            $edad = intval($datos['edad']);
            if ($edad < 1 || $edad > 200) {
                return "La edad debe estar entre 1 y 120 años.";
            }

            // Validar CURP (formato mexicano)
            if (!preg_match('/^[A-Z]{4}[0-9]{6}[A-Z]{6}[0-9A-Z]{2}$/', trim($datos['curp']))) {
                return "El formato del CURP es inválido.";
            }

            // Validar teléfono (10 dígitos)
            if (!preg_match('/^\d{10}$/', trim($datos['telefono']))) {
                return "El número de teléfono debe tener 10 dígitos.";
            }

            // Validar email
            if (!preg_match('/^[\w\.-]+@[\w\.-]+\.[a-zA-Z]{2,}$/', trim($datos['correo']))) {
                return "El formato del email es inválido.";
            }

            // Validar escolaridad (máximo 50 caracteres)
            if (strlen(trim($datos['escolaridad'])) > 50) {
                return "La escolaridad no puede exceder los 50 caracteres.";
            }

            // Validar especialidad (máximo 50 caracteres)
            if (isset($datos['especialidad']) && strlen(trim($datos['especialidad'])) > 50) {
                return "La especialidad no puede exceder los 50 caracteres.";
            }

            // Validar idioma (máximo 30 caracteres)
            if (isset($datos['idioma']) && strlen(trim($datos['idioma'])) > 30) {
                return "El idioma no puede exceder los 30 caracteres.";
            }

            // Validar discapacidad (máximo 50 caracteres)
            if (isset($datos['discapacidad']) && strlen(trim($datos['discapacidad'])) > 50) {
                return "La discapacidad no puede exceder los 50 caracteres.";
            }

            // Validar puestos (máximo 50 caracteres cada uno)
            if (isset($datos['puesto1']) && strlen(trim($datos['puesto1'])) > 50) {
                return "El puesto 1 no puede exceder los 50 caracteres.";
            }
            if (isset($datos['puesto2']) && strlen(trim($datos['puesto2'])) > 50) {
                return "El puesto 2 no puede exceder los 50 caracteres.";
            }

            // Validar consejero (3-30 caracteres)
            $consejero = trim($datos['consejero']);
            if (strlen($consejero) < 3 || strlen($consejero) > 30) {
                return "El consejero debe tener entre 3 y 30 caracteres.";
            }

            // Validar ubicación (máximo 30 caracteres cada uno)
            if (strlen(trim($datos['estado'])) > 30) {
                return "El estado no puede exceder los 30 caracteres.";
            }
            if (strlen(trim($datos['municipio'])) > 30) {
                return "El municipio no puede exceder los 30 caracteres.";
            }
            if (isset($datos['colonia']) && strlen(trim($datos['colonia'])) > 30) {
                return "La colonia no puede exceder los 30 caracteres.";
            }

            // Validar experiencias (máximo 100 caracteres cada una)
            if (isset($datos['experiencia1']) && strlen(trim($datos['experiencia1'])) > 100) {
                return "La experiencia 1 no puede exceder los 100 caracteres.";
            }
            if (isset($datos['experiencia2']) && strlen(trim($datos['experiencia2'])) > 100) {
                return "La experiencia 2 no puede exceder los 100 caracteres.";
            }

            // Validar fecha (no puede ser futura)
            $fecha = trim($datos['fecha']);
            if (strtotime($fecha) > time()) {
                return "La fecha no puede ser futura.";
            }

            // Si todas las validaciones pasan
            return true;
        }

        //- - - - - - - - - - - - - - ACTUALIZAR  - - - - - - - - - - - - - //
        public function update($id)
        {
            // Verificar autenticación
            if (!Auth::is_valid()) {
                Flash::error("Debes iniciar sesión para acceder a esta sección");
                Redirect::to("login");
                return;
            }
            
            // Verificar permisos - solo usuarios autorizados pueden acceder
            if (Auth::get('username') !== 'Lolita' && Auth::get('username') !== 'Mane') {
                Redirect::to("index");
                return;
            }
            
            $this->title = "Actualizar";
            $this->subtitle = "Actualizar información del solicitante";
            
            $agendas = new Agendas();
            
            // Cargar los datos existentes del solicitante
            $this->agendas = $agendas->find($id);
            
            if (!$this->agendas) {
                Flash::error("No se encontró el solicitante");
                Redirect::to("agendas/");
                return;
            }
            
            if (Input::hasPost('agendas')) {
                $datos = Input::post('agendas');
                
                // Llamar a la función de validación
                $validacion = $this->validar($datos);
                if ($validacion !== true) {
                    Flash::error($validacion);
                    return;
                }
                
                // Actualizar el registro
                if ($agendas->update($datos)) {
                    Flash::valid("El solicitante se actualizó con éxito");
                    Redirect::to("agendas/");
                } else {
                    Flash::error("Error al actualizar al solicitante");
                }
            }
        }
    
        //- - - - - - - - - - - - - - ELIMINAR  - - - - - - - - - - - - - //
        public function delete($id)
        {
            // Verificar autenticación y permisos
            if (!Auth::is_valid() || (Auth::get('username') !== 'Lolita' && Auth::get('username') !== 'Mane')) {
                Redirect::to("login");
                return;
            }
            
            $agendas = new Agendas();
            if ($agendas->delete($id)) {
                Flash::valid("Solicitante eliminado con éxito");
            } else {
                Flash::error("Error al eliminar el solicitante");
            }
            
            Redirect::to("agendas/");
        }
}