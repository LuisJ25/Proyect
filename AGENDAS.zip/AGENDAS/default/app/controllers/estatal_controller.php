<?php

// app/controller/productos_controller.php
class EstatalController extends AppController{
    //- - - - - - - - - - - - - - INDEX  - - - - - - - - - - - - - //

    public function index(){
        // Verificar autenticación
        if (!Auth::is_valid()) {
            Flash::error("Debes iniciar sesión para acceder a esta sección");
            Redirect::to("login");
            return;
        }
        
        // Verificar permisos - solo Luis25 y Mane25 pueden acceder a Federal
        if (Auth::get('username') !== 'Luis') {
            Redirect::to("index");
            return;
        }
        
        $this->title = "Estatal";
        $this->subtitle = "Lista de vacantes";
        //Tablas de la base de datos
        $this->estatal = (new Estatal())->find();
    }
    //- - - - - - - - - - - - - - SHOW  - - - - - - - - - - - - - //
    public function show($id){
        // Verificar autenticación
        if (!Auth::is_valid()) {
            Flash::error("Debes iniciar sesión para acceder a esta sección");
            Redirect::to("login");
            return;
        }
        
        // Verificar permisos - solo Luis25 y Mane25 pueden acceder a Federal
        if (Auth::get('username') !== 'Luis') {            
            Redirect::to("index");
            return;
        }
        
        $this->title = "Informacion";
        $this->subtitle = "Informacion del vacante";
        $this->estatal = (new Estatal())->find($id);
    }
    //- - - - - - - - - - - - - - REGISTRAR  - - - - - - - - - - - - - //
    public function registrar()
    {
        // Verificar autenticación
        if (!Auth::is_valid()) {
            Flash::error("Debes iniciar sesión para acceder a esta sección");
            Redirect::to("login");
            return;
        }
        
        // Verificar permisos - solo Luis25 y Mane25 pueden acceder a Federal
        if (Auth::get('username') !== 'Luis') {
            Redirect::to("index");
            return;
        }
        
        $this->title = "Registrar";
        $this->subtitle = "Registrar nuevo vacante";

        if (Input::hasPost('estatal')) {
            $datos = Input::post('estatal');

            // Llamar a la función de validación
            $validacion = $this->validar($datos);
            if ($validacion !== true) {
                Flash::error($validacion);
                return;
            }
            // Crear el objeto de cliente
            $agendas = new Estatal($datos);
            if ($agendas->create()) {
                Flash::valid("El vacante se a registrado con éxito");
                Input::delete();
            } else {
                Flash::error("Error al registrar al vacante");
            }
        }
    }
    // - - - - - - - - - - - - - - - - - -  -  (VALIDACIONES) - - - - - - - - - - - - - - - - - - - - - - //
    private function validar($datos)
    {
        // Validar que los campos no estén vacíos
        foreach ($datos as $campo => $valor) {
            if (empty(trim($valor))) {
                return "El campo '$campo' es obligatorio.";
            }
        }
        // Validar que el campo 'nombre' tenga entre 10 y 30 caracteres
        if (strlen(trim($datos['nombre'])) < 3 || strlen(trim($datos['nombre'])) > 30) {
            return "El nombre debe tener entre 3 y 30 caracteres.";
        }
        // Validar que el campo 'nombre' contenga solo caracteres alfabéticos y espacios
        if (!preg_match('/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/', trim($datos['nombre']))) {
            return "El nombre solo puede contener letras y espacios.";
        }

        // Validar que el campo 'email' tenga un formato válido
        if (isset($datos['email']) && !preg_match('/^[\w\.-]+@[\w\.-]+\.[a-zA-Z]{2,}$/', $datos['email'])) {
            return "El formato del email es inválido.";
        }
        // Validar que el campo 'telefono' tenga un formato válido
        if (!preg_match('/^\d{10}$/', trim($datos['telefono']))) {
            return "El número de teléfono debe tener 10 dígitos.";
        }
        // Si todas las validaciones pasan
        return true;
    }
    // - - - - - - - - - - - - - - - - - -  -  () - - - - - - - - - - - - - - - - - - - - - - //
}