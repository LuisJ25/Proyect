<?php

// app/controller/categorias_controller.php
class AdministradorController extends AppController{
    //- - - - - - - - - - - - - - INDEX  - - - - - - - - - - - - - //
    public function index(){
        // Verificar autenticación
        if (!Auth::is_valid()) {
            Flash::error("Debes iniciar sesión para acceder a esta sección");
            Redirect::to("login");
            return;
        }
        
        // Verificar permisos - solo Lolita25 puede acceder a Recepción
        if (Auth::get('username') !== 'sistemas') {
            Redirect::to("index");
            return;
        }
        
        $this->title = "Administrador";
        $this->subtitle = "Lista de los usuarios del sistema";
        //Tablas de la base de datos
        $this->usuarios = (new Usuarios())->find();
    }
    //- - - - - - - - - - - - - - SHOW  - - - - - - - - - - - - - //
    public function show($id){
        // Verificar autenticación
        if (!Auth::is_valid()) {
            Flash::error("Debes iniciar sesión para acceder a esta sección");
            Redirect::to("login");
            return;
        }
        
        // Verificar permisos - solo Lolita25 puede acceder a Recepción
        if (Auth::get('username') !== 'sistemas') {
            Redirect::to("index");
            return;
        }
        
        $this->title = "Informacion";
        $this->subtitle = "Informacion de los usuarios";
        $this->usuarios = (new Usuarios())->find($id);
    }
    //- - - - - - - - - - - - - - REGISTRAR  - - - - - - - - - - - - - //
    public function registrar()
    {
        // Verificar autenticación
        if (!Auth::is_valid()) {
            Flash::error("Debes iniciar sesión para acceder a esta sección");
            Redirect::to("login");
            return;
        }
        
        // Verificar permisos - solo Lolita25 puede acceder a Recepción
        if (Auth::get('username') !== 'sistemas') {
            Redirect::to("index");
            return;
        }
        
        $this->title = "Registrar";
        $this->subtitle = "Registrar nuevo usuario";

        if (Input::hasPost('usuarios')) {
            $datos = Input::post('usuarios');

            // Crear el objeto de categoría
            $usuarios = new Usuarios($datos);
            if ($usuarios->create()) {
                Flash::valid("El usuario se a registrado con éxito");
                Input::delete();
            } else {
                Flash::error("Error al registrar al usuario");
            }
        }
    }
// - - - - - - - - - - - - - - - - - -  -  (VALIDACIONES) - - - - - - - - - - - - - - - - - - - - - - //
    private function validar($datos)
        {
            // Validar que los campos obligatorios no estén vacíos
            $camposObligatorios = [
                'nombrec' => 'Nombre del cliente',
                'edad' => 'Edad',
                'curp' => 'CURP',
                'telefono' => 'Teléfono',
                'correo' => 'Email',
                'escolaridad' => 'Escolaridad',
                'consejero' => 'Consejero',
                'estado' => 'Estado',
                'municipio' => 'Municipio',
                'fecha' => 'Fecha'
            ];

            foreach ($camposObligatorios as $campo => $nombre) {
                if (empty(trim($datos[$campo] ?? ''))) {
                    return "El campo '$nombre' es obligatorio.";
                }
            }

            // Validar nombre del cliente (3-30 caracteres, solo letras y espacios)
            $nombre = trim($datos['nombrec']);
            if (strlen($nombre) < 3 || strlen($nombre) > 30) {
                return "El nombre debe tener entre 3 y 30 caracteres.";
            }
            if (!preg_match('/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/', $nombre)) {
                return "El nombre solo puede contener letras y espacios.";
            }

            // Validar edad (1-120 años)
            $edad = intval($datos['edad']);
            if ($edad < 1 || $edad > 200) {
                return "La edad debe estar entre 1 y 120 años.";
            }

            // Validar CURP (formato mexicano)
            if (!preg_match('/^[A-Z]{4}[0-9]{6}[A-Z]{6}[0-9A-Z]{2}$/', trim($datos['curp']))) {
                return "El formato del CURP es inválido.";
            }

            // Validar teléfono (10 dígitos)
            if (!preg_match('/^\d{10}$/', trim($datos['telefono']))) {
                return "El número de teléfono debe tener 10 dígitos.";
            }

            // Validar email
            if (!preg_match('/^[\w\.-]+@[\w\.-]+\.[a-zA-Z]{2,}$/', trim($datos['correo']))) {
                return "El formato del email es inválido.";
            }

            // Validar escolaridad (máximo 50 caracteres)
            if (strlen(trim($datos['escolaridad'])) > 50) {
                return "La escolaridad no puede exceder los 50 caracteres.";
            }

            // Validar especialidad (máximo 50 caracteres)
            if (isset($datos['especialidad']) && strlen(trim($datos['especialidad'])) > 50) {
                return "La especialidad no puede exceder los 50 caracteres.";
            }

            // Validar idioma (máximo 30 caracteres)
            if (isset($datos['idioma']) && strlen(trim($datos['idioma'])) > 30) {
                return "El idioma no puede exceder los 30 caracteres.";
            }

            // Validar discapacidad (máximo 50 caracteres)
            if (isset($datos['discapacidad']) && strlen(trim($datos['discapacidad'])) > 50) {
                return "La discapacidad no puede exceder los 50 caracteres.";
            }

            // Validar puestos (máximo 50 caracteres cada uno)
            if (isset($datos['puesto1']) && strlen(trim($datos['puesto1'])) > 50) {
                return "El puesto 1 no puede exceder los 50 caracteres.";
            }
            if (isset($datos['puesto2']) && strlen(trim($datos['puesto2'])) > 50) {
                return "El puesto 2 no puede exceder los 50 caracteres.";
            }

            // Validar consejero (3-30 caracteres)
            $consejero = trim($datos['consejero']);
            if (strlen($consejero) < 3 || strlen($consejero) > 30) {
                return "El consejero debe tener entre 3 y 30 caracteres.";
            }

            // Validar ubicación (máximo 30 caracteres cada uno)
            if (strlen(trim($datos['estado'])) > 30) {
                return "El estado no puede exceder los 30 caracteres.";
            }
            if (strlen(trim($datos['municipio'])) > 30) {
                return "El municipio no puede exceder los 30 caracteres.";
            }
            if (isset($datos['colonia']) && strlen(trim($datos['colonia'])) > 30) {
                return "La colonia no puede exceder los 30 caracteres.";
            }

            // Validar experiencias (máximo 100 caracteres cada una)
            if (isset($datos['experiencia1']) && strlen(trim($datos['experiencia1'])) > 100) {
                return "La experiencia 1 no puede exceder los 100 caracteres.";
            }
            if (isset($datos['experiencia2']) && strlen(trim($datos['experiencia2'])) > 100) {
                return "La experiencia 2 no puede exceder los 100 caracteres.";
            }

            // Validar fecha (no puede ser futura)
            $fecha = trim($datos['fecha']);
            if (strtotime($fecha) > time()) {
                return "La fecha no puede ser futura.";
            }

            // Si todas las validaciones pasan
            return true;
        }
    // - - - - - - - - - - - - - - - - - -  -  () - - - - - - - - - - - - - - - - - - - - - - //

         //- - - - - - - - - - - - - - ACTUALIZAR  - - - - - - - - - - - - - //
        public function update($id)
        {
            // Verificar autenticación
            if (!Auth::is_valid()) {
                Flash::error("Debes iniciar sesión para acceder a esta sección");
                Redirect::to("login");
                return;
            }
            
            // Verificar permisos - solo usuarios autorizados pueden acceder
            if (Auth::get('username') !== 'sistemas') {
                Redirect::to("index");
                return;
            }
            
            $this->title = "Actualizar";
            $this->subtitle = "Actualizar información del usuario";
            
            $usuarios = new Usuarios();
            
            // Cargar los datos existentes del solicitante
            $this->usuarios = $usuarios->find($id);
            
            if (!$this->usuarios) {
                Flash::error("No se encontró al usuario");
                Redirect::to("administrador/");
                return;
            }
            
            if (Input::hasPost('usuarios')) {
                $datos = Input::post('usuarios');
                
                // Actualizar el registro
                if ($usuarios->update($datos)) {
                    Flash::valid("El usuario se actualizó con éxito");
                    Redirect::to("administrador/");
                } else {
                    Flash::error("Error al actualizar al usuario");
                }
            }
        }
    
        //- - - - - - - - - - - - - - ELIMINAR  - - - - - - - - - - - - - //
        public function delete($id)
        {
            // Verificar autenticación y permisos
            if (!Auth::is_valid() || (Auth::get('username') !== 'sistemas')) {
                Redirect::to("login");
                return;
            }
            
            $usuarios = new Usuarios();
            if ($usuarios->delete($id)) {
                Flash::valid("Usuario eliminado con éxito");
            } else {
                Flash::error("Error al eliminar al usuario");
            }
            
            Redirect::to("administrador/");
        }
}