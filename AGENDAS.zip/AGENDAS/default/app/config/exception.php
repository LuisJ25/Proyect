<?php

return [
    // array de IPs para mostrar la exception de desarrollador 
    // ej: ['12.12.12.12','23.23.23.23']
    'trustedIp' => []
];

