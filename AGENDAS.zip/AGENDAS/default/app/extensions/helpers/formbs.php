<?php

class Formbs{
    protected static function attrsdefaut($attrs, $defaults)
    {
        foreach ($defaults as $k => $v) {
            if (isset($attrs[$k])) {
                if (strpos($attrs[$k], $v) === false) {
                    $attrs[$k] .= ' '.$v;
                }
            } else {
                $attrs[$k] = $v;
            }
        }
        return $attrs;
    }

    // - - - - - - - - - - - - - - -  BOTONES  - - - - - - - - - - - - - - - //

    // - - -  - - - - - - - - - -  GUARDAR - - - - - - - - - - - - - - - - - //
    public static function btn_aceptar($text = "Guardar", $attrs = []){
        $text = " ".$text;
        $attrs = Formbs::attrsdefaut($attrs, ["class" => "btn btn-success mt-3 me-2"]);
        return Form::submit($text, $attrs);
    }
    // - - -  - - - - - - - - - -  CANCELAR - - - - - - - - - - - - - - - - - //
    public static function btn_cancelar($text = "Cancelar", $url = "", $attrs = []) {
        $text = " " . $text;
        // Asegúrate de que la URL esté correctamente escapada
        $url = htmlspecialchars(trim(URL_APP, '/') . '/' . ltrim($url, '/'), ENT_QUOTES, 'UTF-8');
        // Agregar un evento onclick que redirija a la URL especificada
        $attrs = Formbs::attrsdefaut($attrs, [
            "class" => "btn btn-danger mt-3 me-2",
            "type" => "button", // Asegúrate de que el tipo sea "button" para evitar el envío del formulario
            "onclick" => "if (confirm('¿Estás seguro de que deseas cancelar?')) { window.location.href='{$url}'; return false;}" // Redirige a la URL especificada al hacer clic
        ]);
        return Form::button($text, $attrs);
    }

    // - - -  - - - - - - - - - -  REGRESAR  GENERAL - - - - - - - - - - - - - - - - - //
    public static function btn_regresar($text = "Regresar", $url = "", $attrs = []) {
        $text = " " . $text;
        // Asegúrate de que la URL esté correctamente escapada
        $url = htmlspecialchars(trim(URL_APP, '/') . '/' . ltrim($url, '/'), ENT_QUOTES, 'UTF-8');
        // Agregar un evento onclick que redirija a la URL especificada
        $attrs = Formbs::attrsdefaut($attrs, [
            "class" => "btn btn-warning mt-3",
            "type" => "button", // Asegúrate de que el tipo sea "button" para evitar el envío del formulario
            "onclick" => "window.location.href='{$url}'; return false;" // Redirige a la URL especificada al hacer clic
        ]);
        return Form::button($text, $attrs);
    }
}